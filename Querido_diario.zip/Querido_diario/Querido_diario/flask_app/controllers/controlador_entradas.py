from flask import Blueprint, redirect, render_template, request, session, url_for

from flask_app.models.entrada import borrar_entrada, crear_entrada, cargar_entradas, obtener_entrada_por_id, actualizar_entrada

entradas = Blueprint("entradas", __name__)

# Muestra solo las entradas del usuario que tiene sesión activa.
@entradas.route("/dashboard")
def dashboard():
    if session.get("usuario_id") is None:
        return redirect(url_for("usuarios.inicio"))

    lista = cargar_entradas()
    usuario_id = session["usuario_id"]
    entradas_usuario = [e for e in lista if e["usuario_id"] == usuario_id]
    return render_template("dashboard.html", entradas=entradas_usuario)


# Guarda una entrada nueva y luego la lleva a su detalle.
@entradas.route("/nueva-entrada", methods=["GET", "POST"])
def nueva_entrada():
    if session.get("usuario_id") is None:
        return redirect(url_for("usuarios.inicio"))

    if request.method == "POST":
        entrada = crear_entrada(request.form, session["usuario_id"])
        return redirect(url_for("entradas.detalle", entrada_id=entrada["id"]))

    return render_template("nueva_entrada.html")


@entradas.route("/entrada/<int:entrada_id>")
def detalle(entrada_id):
    if session.get("usuario_id") is None:
        return redirect(url_for("usuarios.inicio"))

    entrada = obtener_entrada_por_id(entrada_id)
    if entrada is None:
        return redirect(url_for("entradas.dashboard"))
    return render_template("detalle_entrada.html", entrada=entrada)


@entradas.route("/entrada/<int:entrada_id>/editar", methods=["GET", "POST"])
def editar_entrada(entrada_id):
    if session.get("usuario_id") is None:
        return redirect(url_for("usuarios.inicio"))

    entrada = obtener_entrada_por_id(entrada_id)
    if entrada is None:
        return redirect(url_for("entradas.dashboard"))

    if request.method == "POST":
        nueva = actualizar_entrada(entrada_id, request.form)
        if nueva is not None:
            return redirect(url_for("entradas.detalle", entrada_id=entrada_id))

    return render_template("editar_entrada.html", entrada=entrada)


# Busca coincidencias dentro del texto o título de las entradas del usuario.
@entradas.route("/buscar")
def buscar():
    if session.get("usuario_id") is None:
        return redirect(url_for("usuarios.inicio"))

    usuario_id = session["usuario_id"]
    termino = (request.args.get("q") or "").strip()
    entradas_usuario = [
        entrada for entrada in cargar_entradas() if entrada.get("usuario_id") == usuario_id
    ]

    if termino:
        termino_busqueda = termino.lower()
        entradas_usuario = [
            entrada
            for entrada in entradas_usuario
            if termino_busqueda in (entrada.get("titulo") or "").lower()
            or termino_busqueda in (entrada.get("texto") or "").lower()
        ]
        if len(entradas_usuario) == 1:
            return redirect(url_for("entradas.detalle", entrada_id=entradas_usuario[0]["id"]))

    return render_template("buscar.html", entradas=entradas_usuario)


@entradas.route("/entrada/<int:entrada_id>/borrar", methods=["POST"])
def borrar(entrada_id):
    if session.get("usuario_id") is None:
        return redirect(url_for("usuarios.inicio"))

    borrar_entrada(entrada_id)
    return redirect(url_for("entradas.dashboard"))
