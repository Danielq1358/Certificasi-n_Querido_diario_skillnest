from flask import Blueprint, redirect, render_template, request, session, url_for

from flask_app.models.usuario import autenticar_usuario, buscar_usuario_por_email, crear_usuario, validar_registro

usuarios = Blueprint("usuarios", __name__)

# Esta ruta muestra la pantalla principal de ingreso/registro.
@usuarios.route("/ingreso", methods=["GET", "POST"])
def inicio():
    if request.method == "POST":
        return redirect(url_for("entradas.dashboard"))
    if session.get("usuario_id") is not None:
        return redirect(url_for("entradas.dashboard"))
    return render_template("ingreso.html")


# Registra un nuevo usuario y crea la sesión si todo está correcto.
@usuarios.route("/registrar", methods=["POST"])
def registrar():
    errores = validar_registro(request.form)
    if errores:
        return render_template("ingreso.html", errores=errores, valores=request.form)

    if buscar_usuario_por_email(request.form.get("email", "")):
        return render_template("ingreso.html", errores=["El correo ya existe."], valores=request.form)

    usuario = crear_usuario(request.form)
    session["usuario_id"] = usuario["id"]
    session["usuario_nombre"] = usuario["nombre"]
    return redirect(url_for("entradas.dashboard"))


# Valida el correo y la contraseña para permitir entrar al dashboard.
@usuarios.route("/iniciar-sesion", methods=["POST"])
def iniciar_sesion():
    email = (request.form.get("email_login") or "").strip().lower()
    contrasena = request.form.get("password_login") or ""
    usuario = autenticar_usuario(email, contrasena)

    if usuario is None:
        return render_template("ingreso.html", errores=["Correo o contraseña incorrectos."])

    session["usuario_id"] = usuario["id"]
    session["usuario_nombre"] = usuario["nombre"]
    return redirect(url_for("entradas.dashboard"))


@usuarios.route("/cerrar-sesion")
def cerrar_sesion():
    session.clear()
    return redirect(url_for("usuarios.inicio"))
