from flask import Flask, g, redirect, session, url_for

from flask_app.config.config import Config


def crear_app():
    app = Flask(
        __name__,
        template_folder="templates",
        static_folder="static",
        static_url_path="/static",
    )
    app.config.from_object(Config)
    app.config["USUARIOS"] = []
    app.config["ENTRADAS"] = []

    from flask_app.controllers.controlador_usuarios import usuarios
    from flask_app.controllers.controlador_entradas import entradas

    app.register_blueprint(usuarios)
    app.register_blueprint(entradas)

    @app.before_request
    def preparar_sesion():
        g.usuario = None
        usuario_id = session.get("usuario_id")
        if usuario_id is not None:
            for usuario in app.config["USUARIOS"]:
                if usuario["id"] == usuario_id:
                    g.usuario = usuario
                    break

    @app.route("/")
    def inicio():
        if session.get("usuario_id") is not None:
            return redirect(url_for("entradas.dashboard"))
        return redirect(url_for("usuarios.inicio"))

    @app.errorhandler(404)
    def pagina_no_encontrada(error):
        if session.get("usuario_id") is not None:
            return redirect(url_for("entradas.dashboard"))
        return redirect(url_for("usuarios.inicio"))

    return app
