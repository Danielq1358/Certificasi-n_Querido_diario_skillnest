import os

from dotenv import load_dotenv

load_dotenv()


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "4953a8da5ac8602b944eae6cab8dea3ff72980bc60ff85b32c454cd131779021")
    DB_HOST = os.environ.get("MYSQL_HOST", "localhost")
    DB_PORT = int(os.environ.get("MYSQL_PORT", 3306))
    DB_USER = os.environ.get("MYSQL_USER", "root")
    DB_PASSWORD = os.environ.get("MYSQL_PASSWORD", "1234")
    DB_NAME = os.environ.get("MYSQL_DB", "querido_diario")

    DATABASE_URL = (
        f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    )
