from flask_app.config.mysql_connection import connect_to_mysql

# Aquí se guardan todas las entradas del diario mientras la app corre.
ENTRADAS = []


class Entrada:
    def __init__(self, data):
        self.id = data.get("id") or data.get("id_entrada")
        self.fecha = (data.get("fecha") or "").strip()
        self.titulo = (data.get("titulo") or "").strip()
        self.texto = (data.get("texto") or "").strip()
        self.usuario_id = data.get("usuario_id")

    def to_dict(self):
        return {
            "id": self.id,
            "fecha": self.fecha,
            "titulo": self.titulo,
            "texto": self.texto,
            "usuario_id": self.usuario_id,
        }

    @classmethod
    def guardar(cls, datos, usuario_id):
        try:
            db = connect_to_mysql("querido_diario")
            query = """
                INSERT INTO entradas (fecha, titulo, texto, usuario_id)
                VALUES (%(fecha)s, %(titulo)s, %(texto)s, %(usuario_id)s)
            """
            resultado = db.query_db(query, {**datos, "usuario_id": usuario_id})
            if resultado is not False and resultado is not None:
                return resultado
        except Exception:
            pass
        return None

    @classmethod
    def obtener_por_id(cls, entrada_id):
        for entrada in ENTRADAS:
            if entrada["id"] == entrada_id:
                return cls(entrada).to_dict()
        return None

    @classmethod
    def listar(cls, usuario_id=None):
        if usuario_id is None:
            return [e.copy() for e in ENTRADAS]
        return [e.copy() for e in ENTRADAS if e.get("usuario_id") == usuario_id]

    @classmethod
    def actualizar(cls, entrada_id, datos):
        for entrada in ENTRADAS:
            if entrada["id"] == entrada_id:
                entrada["fecha"] = (datos.get("fecha") or "").strip()
                entrada["titulo"] = (datos.get("titulo") or "").strip()
                entrada["texto"] = (datos.get("texto") or "").strip()
                return entrada
        return None

    @classmethod
    def borrar(cls, entrada_id):
        for indice, entrada in enumerate(ENTRADAS):
            if entrada["id"] == entrada_id:
                del ENTRADAS[indice]
                return True
        return False


def cargar_entradas():
    return ENTRADAS


def obtener_entrada_por_id(entrada_id):
    return Entrada.obtener_por_id(entrada_id)


# Crea una nueva entrada y la guarda al inicio de la lista para que aparezca primero.
def crear_entrada(datos, usuario_id):
    siguiente_id = max((e["id"] for e in ENTRADAS), default=0) + 1
    nueva_entrada = {
        "id": siguiente_id,
        "fecha": (datos.get("fecha") or "").strip(),
        "titulo": (datos.get("titulo") or "").strip(),
        "texto": (datos.get("texto") or "").strip(),
        "usuario_id": usuario_id,
    }
    ENTRADAS.insert(0, nueva_entrada)
    return nueva_entrada


def actualizar_entrada(entrada_id, datos):
    return Entrada.actualizar(entrada_id, datos)


def borrar_entrada(entrada_id):
    return Entrada.borrar(entrada_id)
