import re

from flask import flash

from flask_app.config.mysql_connection import connect_to_mysql

EMAIL_REGEX = re.compile(r"^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$")

# Lista temporal donde se guardan los usuarios mientras la app está en ejecución.
USUARIOS = []


class Usuario:
    def __init__(self, data):
        self.id = data.get("id") or data.get("id_usuario")
        self.nombre = (data.get("nombre") or "").strip()
        self.apellido = (data.get("apellido") or "").strip()
        self.email = ((data.get("email") or "").strip().lower())
        self.contrasena = (data.get("contrasena") or "").strip()

    def to_dict(self):
        return {
            "id": self.id,
            "nombre": self.nombre,
            "apellido": self.apellido,
            "email": self.email,
            "contrasena": self.contrasena,
        }

    @classmethod
    def guardar(cls, formulario):
        try:
            db = connect_to_mysql("querido_diario")
            query = """
                INSERT INTO usuarios (nombre, apellido, email, contrasena)
                VALUES (%(nombre)s, %(apellido)s, %(email)s, %(contrasena)s)
            """
            resultado = db.query_db(query, formulario)
            if resultado is not False and resultado is not None:
                return resultado
        except Exception:
            pass
        return None

    @classmethod
    def obtener_por_email(cls, formulario):
        email = ""
        if isinstance(formulario, dict):
            email = (formulario.get("email") or "").strip().lower()
        else:
            email = (formulario or "").strip().lower()

        try:
            db = connect_to_mysql("querido_diario")
            resultado = db.query_db("SELECT * FROM usuarios WHERE email = %(email)s;", {"email": email}) or []
            if resultado:
                return cls(resultado[0])
        except Exception:
            pass

        for usuario in USUARIOS:
            if usuario["email"] == email:
                return cls(usuario)
        return None

    @classmethod
    def obtener_por_id(cls, formulario):
        usuario_id = formulario.get("id_usuario") if isinstance(formulario, dict) else formulario
        for usuario in USUARIOS:
            if usuario["id"] == usuario_id:
                return cls(usuario)
        return None

    @staticmethod
    def validar_registro(formulario):
        es_valido = True
        nombre = (formulario.get("nombre") or "").strip()
        apellido = (formulario.get("apellido") or "").strip()
        email = (formulario.get("email") or "").strip().lower()
        contrasena = formulario.get("contrasena") or ""
        confirmar = formulario.get("confirmar_contrasena") or ""

        if len(nombre) < 2:
            flash("El nombre debe tener al menos 2 caracteres.", "registro")
            es_valido = False
        if len(apellido) < 2:
            flash("El apellido debe tener al menos 2 caracteres.", "registro")
            es_valido = False
        if not EMAIL_REGEX.match(email):
            flash("El formato del email es inválido.", "registro")
            es_valido = False
        else:
            usuario_existente = Usuario.obtener_por_email({"email": email})
            if usuario_existente:
                flash("Este email ya se encuentra registrado.", "registro")
                es_valido = False
        if len(contrasena) < 8:
            flash("La contraseña debe tener al menos 8 caracteres.", "registro")
            es_valido = False
        if contrasena != confirmar:
            flash("Las contraseñas no coinciden.", "registro")
            es_valido = False

        return es_valido


def cargar_usuarios():
    return USUARIOS


def validar_registro(datos):
    errores = []
    nombre = (datos.get("nombre") or "").strip()
    apellido = (datos.get("apellido") or "").strip()
    email = (datos.get("email") or "").strip().lower()
    contrasena = datos.get("contrasena") or ""
    confirmar = datos.get("confirmar_contrasena") or ""

    if len(nombre) < 2:
        errores.append("El nombre debe tener al menos 2 caracteres.")
    if len(apellido) < 2:
        errores.append("El apellido debe tener al menos 2 caracteres.")
    if not EMAIL_REGEX.match(email):
        errores.append("Ingresa un correo electrónico válido.")
    if len(contrasena) < 8:
        errores.append("La contraseña debe tener al menos 8 caracteres.")
    if contrasena != confirmar:
        errores.append("La confirmación de la contraseña no coincide.")

    return errores


# Busca un usuario por correo para evitar duplicados y para iniciar sesión.
def buscar_usuario_por_email(email):
    email_normalizado = (email or "").strip().lower()
    for usuario in USUARIOS:
        if usuario["email"] == email_normalizado:
            return usuario
    usuario_obj = Usuario.obtener_por_email(email_normalizado)
    if usuario_obj is not None:
        return usuario_obj.to_dict()
    return None


def crear_usuario(datos):
    siguiente_id = max((u["id"] for u in USUARIOS), default=0) + 1
    nuevo_usuario = {
        "id": siguiente_id,
        "nombre": (datos.get("nombre") or "").strip(),
        "apellido": (datos.get("apellido") or "").strip(),
        "email": ((datos.get("email") or "").strip().lower()),
        "contrasena": (datos.get("contrasena") or "").strip(),
    }
    USUARIOS.append(nuevo_usuario)
    return nuevo_usuario


def autenticar_usuario(email, contrasena):
    usuario = buscar_usuario_por_email(email)
    if usuario and usuario["contrasena"] == contrasena:
        return usuario
    return None
