# Querido Diario

Aplicación web para guardar pensamientos, recuerdos y entradas personales en un diario.

## ¿Qué hace?

- Crear cuenta
- Iniciar sesión
- Añadir entradas
- Ver cada entrada
- Editar entradas
- Eliminar entradas
- Buscar entradas

## Tecnologías

- Python
- Flask
- HTML
- CSS
- MySQL
- PyMySQL
- python-dotenv

## Estructura de carpetas

```text
Querido_diario/
├── .env
├── .gitignore
├── .venv/
├── README.md
├── flask_app/
│   ├── __init__.py
│   ├── app.py
│   ├── config/
│   │   ├── __init__.py
│   │   ├── config.py
│   │   └── mysql_connection.py
│   ├── controllers/
│   │   ├── __init__.py
│   │   ├── controlador_entradas.py
│   │   └── controlador_usuarios.py
│   ├── models/
│   │   ├── __init__.py
│   │   ├── entrada.py
│   │   └── usuario.py
│   ├── static/
│   │   └── css/
│   │       └── estilos.css
│   └── templates/
│       ├── buscar.html
│       ├── dashboard.html
│       ├── detalle_entrada.html
│       ├── editar_entrada.html
│       ├── index.html
│       ├── ingreso.html
│       └── nueva_entrada.html
└── resources/
```

## Requisitos

- Python 3.10 o superior
- Flask
- PyMySQL
- python-dotenv
- MySQL

## Instalación

1. Entrar a la carpeta del proyecto.
2. Crear un entorno virtual:

```bash
python -m venv .venv
```

3. Activar el entorno:

```bash
.
.venv\Scripts\activate
```

4. Instalar dependencias:

```bash
python -m pip install --upgrade pip
python -m pip install flask python-dotenv pymysql
```

## Configuración

Crear un archivo `.env` con este contenido:

```env
SECRET_KEY=mi_clave_secreta
MYSQL_HOST=localhost
MYSQL_PORT=3306
MYSQL_USER=root
MYSQL_PASSWORD=tu_password
MYSQL_DB=querido_diario
```

## Ejecutar la aplicación

Desde la carpeta principal:

```bash
python flask_app/app.py
```

Luego abrir en el navegador:

```text
http://127.0.0.1:5000/ingreso
```

## Cómo funciona

El usuario crea una cuenta, inicia sesión y puede escribir entradas personales. Después puede abrir, editar, borrar o buscar cualquiera de sus notas desde el panel principal.
